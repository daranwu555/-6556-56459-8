@echo off
chcp 65001 >nul
cd /d "%~dp0"
set START_MONEY=500000
echo 測試模式：新帳號起始金額 500,000 元（可測試商店、改名、擴建）
start http://localhost:3000
node server.js
pause
