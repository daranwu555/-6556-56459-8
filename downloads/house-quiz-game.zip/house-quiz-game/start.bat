@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 啟動遊戲... 請用瀏覽器開啟 http://localhost:3000
start http://localhost:3000
node server.js
pause
