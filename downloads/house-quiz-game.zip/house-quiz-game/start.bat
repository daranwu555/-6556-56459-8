@echo off
chcp 65001 >nul
cd /d "%~dp0"
title 小屋大亨
where node >nul 2>nul
if errorlevel 1 (
  echo [錯誤] 找不到 Node.js。
  echo 請先安裝 Node.js（LTS 版）：https://nodejs.org ，安裝完成後重新雙擊本檔案。
  start https://nodejs.org
  pause
  exit /b 1
)
echo 目前的 Node.js 版本：
node -v
set OPEN_BROWSER=1
node server.js
echo.
echo 伺服器已停止。如果一開始就停止，請把上面的紅字錯誤訊息截圖給我。
pause
