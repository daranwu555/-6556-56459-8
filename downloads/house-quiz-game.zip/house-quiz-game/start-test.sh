#!/bin/bash
cd "$(dirname "$0")"
export START_MONEY=500000
echo "測試模式：新帳號起始金額 500,000 元"
node server.js
