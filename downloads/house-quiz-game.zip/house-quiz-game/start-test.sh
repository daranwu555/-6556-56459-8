#!/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null; then echo "找不到 Node.js，請先安裝：https://nodejs.org"; exit 1; fi
export START_MONEY=500000
echo "測試模式：新帳號起始金額 500,000 元"
OPEN_BROWSER=1 node server.js
