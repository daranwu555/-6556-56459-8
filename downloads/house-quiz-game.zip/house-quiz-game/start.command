#!/bin/bash
cd "$(dirname "$0")"
echo "啟動遊戲... 請用瀏覽器開啟 http://localhost:3000"
open http://localhost:3000
node server.js
