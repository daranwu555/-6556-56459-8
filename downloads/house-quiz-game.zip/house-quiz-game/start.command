#!/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null; then echo "找不到 Node.js，請先安裝：https://nodejs.org"; read -p "按 Enter 結束"; exit 1; fi
node -v
OPEN_BROWSER=1 node server.js
read -p "伺服器已停止，按 Enter 結束"
